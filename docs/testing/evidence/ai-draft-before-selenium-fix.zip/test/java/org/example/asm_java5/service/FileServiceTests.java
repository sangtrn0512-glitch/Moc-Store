package org.example.asm_java5.service;

import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import org.example.asm_java5.support.CaseIds;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

class FileServiceTests {
  @Test @CaseIds("TC-045") void rejectsEmptyFakeAndOversizedFiles() {
    FileService files=new FileService();
    assertThrows(IllegalArgumentException.class,()->files.save(new MockMultipartFile("photo",new byte[0])));
    assertThrows(IllegalArgumentException.class,()->files.save(new MockMultipartFile("photo","fake.jpg","image/jpeg","plain text".getBytes())));
    assertThrows(IllegalArgumentException.class,()->files.save(new MockMultipartFile("photo",new byte[2*1024*1024+1])));
  }
  @Test @CaseIds("TC-045") void rejectsImageWiderThanFiveThousandPixels() throws Exception {
    ByteArrayOutputStream bytes=new ByteArrayOutputStream(); ImageIO.write(new BufferedImage(5001,1,BufferedImage.TYPE_INT_RGB),"png",bytes);
    assertThrows(IllegalArgumentException.class,()->new FileService().save(new MockMultipartFile("photo","large.png","image/png",bytes.toByteArray())));
  }
}
